import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import numpy as np

# Page configuration
st.set_page_config(
    page_title="IoT Device Analytics Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        margin-bottom: 1.5rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-left: 4px solid;
        transition: transform 0.3s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
    }
    
    .alert-card {
        background: #fff3cd;
        border: 1px solid #ffeaa7;
        border-left: 4px solid #fdcb6e;
        padding: 0.75rem;
        border-radius: 8px;
        margin-bottom: 0.5rem;
    }
    
    .critical-alert {
        background: #f8d7da;
        border: 1px solid #f5c6cb;
        border-left: 4px solid #dc3545;
    }
    
    .warning-alert {
        background: #fff3cd;
        border: 1px solid #ffeaa7;
        border-left: 4px solid #ffc107;
    }
    
    .info-alert {
        background: #d1ecf1;
        border: 1px solid #bee5eb;
        border-left: 4px solid #17a2b8;
    }
    
    .device-card {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        margin-bottom: 1rem;
        border: 1px solid #e0e0e0;
    }
    
    .suspicious-card {
        background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
        color: white;
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 1rem;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.8; }
        100% { opacity: 1; }
    }
    
    .status-indicator {
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        margin-right: 8px;
    }
    
    .status-optimal { background-color: #00b894; }
    .status-warning { background-color: #fdcb6e; }
    .status-critical { background-color: #ff7675; }
    
    .room-energy-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        height: 100%;
    }
    
    .tab-content {
        padding: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Load the dataset
@st.cache_data
def load_data():
    # Load CSV data
    df = pd.read_csv('iot_logs.csv')
    
    # Convert Timestamp to datetime
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    
    # Extract time components
    df['Hour'] = df['Timestamp'].dt.hour
    df['Date'] = df['Timestamp'].dt.date
    df['Day_Name'] = df['Timestamp'].dt.day_name()
    
    return df

# Load data
df = load_data()

# Dashboard Header
st.markdown("""
<div class="main-header">
    <h1 style="margin: 0;">📊 IoT Device Analytics Dashboard</h1>
    <p style="margin: 0; opacity: 0.9;">Real-time analysis of IoT sensor data from smart home devices</p>
</div>
""", unsafe_allow_html=True)

# Top Metrics Row
col1, col2, col3, col4 = st.columns(4)

with col1:
    total_energy = df['Power_Usage_kWh'].sum()
    st.markdown(f"""
    <div class="metric-card" style="border-left-color: #667eea;">
        <div style="font-size: 0.9rem; color: #666; margin-bottom: 0.5rem;">Total Energy Consumed</div>
        <div style="font-size: 1.8rem; font-weight: bold; color: #333;">{total_energy:.1f} kWh</div>
        <div style="font-size: 0.8rem; color: #888;">All Rooms • All Time</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    total_devices = df['Device_ID'].nunique()
    avg_power = df['Power_Consumption_W'].mean()
    st.markdown(f"""
    <div class="metric-card" style="border-left-color: #00b894;">
        <div style="font-size: 0.9rem; color: #666; margin-bottom: 0.5rem;">Active Devices</div>
        <div style="font-size: 1.8rem; font-weight: bold; color: #333;">{total_devices}</div>
        <div style="font-size: 0.8rem; color: #888;">Avg Power: {avg_power:.0f}W</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    critical_alerts = len(df[df['Smoke_Level'].isin(['Critical', 'Warning'])])
    st.markdown(f"""
    <div class="metric-card" style="border-left-color: #ff7675;">
        <div style="font-size: 0.9rem; color: #666; margin-bottom: 0.5rem;">Critical Alerts</div>
        <div style="font-size: 1.8rem; font-weight: bold; color: #333;">{critical_alerts}</div>
        <div style="font-size: 0.8rem; color: #888;">Smoke/Warning Events</div>
    </div>
    """, unsafe_allow_html=True)

with col4:
    avg_temp = df['Room_Temperature_C'].mean()
    avg_humidity = df['Humidity_%'].mean()
    st.markdown(f"""
    <div class="metric-card" style="border-left-color: #fdcb6e;">
        <div style="font-size: 0.9rem; color: #666; margin-bottom: 0.5rem;">Avg Environment</div>
        <div style="font-size: 1.2rem; font-weight: bold; color: #333;">{avg_temp:.1f}°C / {avg_humidity:.0f}%</div>
        <div style="font-size: 0.8rem; color: #888;">Temp / Humidity</div>
    </div>
    """, unsafe_allow_html=True)

# Create tabs for different analyses
tab1, tab2, tab3, tab4 = st.tabs([
    "🏠 Room-wise Energy",
    "📱 Device Status",
    "🚨 Recent Alerts",
    "🔍 Suspicious Activity"
])

# 1. Room-wise Energy Consumption Analysis
with tab1:
    st.subheader("⚡ Room-wise Energy Consumption Analysis")
    
    # Calculate room-wise statistics
    room_stats = df.groupby('Device_ID').agg({
        'Power_Consumption_W': ['mean', 'max', 'sum'],
        'Power_Usage_kWh': 'sum',
        'Room_Temperature_C': 'mean',
        'Humidity_%': 'mean'
    }).round(2)
    
    room_stats.columns = ['Avg_Power_W', 'Max_Power_W', 'Total_Power_W', 'Total_Energy_kWh', 'Avg_Temp_C', 'Avg_Humidity_%']
    room_stats = room_stats.reset_index()
    
    # Create two columns for charts
    col1, col2 = st.columns(2)
    
    with col1:
        # Energy consumption by room (bar chart)
        fig1 = px.bar(
            room_stats,
            x='Device_ID',
            y='Total_Energy_kWh',
            title='Total Energy Consumption by Room',
            color='Total_Energy_kWh',
            color_continuous_scale='Viridis',
            labels={'Device_ID': 'Room', 'Total_Energy_kWh': 'Energy (kWh)'}
        )
        fig1.update_layout(height=400)
        st.plotly_chart(fig1, use_container_width=True)
    
    with col2:
        # Power consumption distribution
        fig2 = px.box(
            df,
            x='Device_ID',
            y='Power_Consumption_W',
            title='Power Consumption Distribution by Room',
            color='Device_ID',
            labels={'Device_ID': 'Room', 'Power_Consumption_W': 'Power (W)'}
        )
        fig2.update_layout(height=400)
        st.plotly_chart(fig2, use_container_width=True)
    
    # Hourly energy pattern - SIMPLIFIED VERSION WITHOUT DUAL AXIS
    st.subheader("📈 Hourly Energy Consumption Pattern")
    
    # Calculate hourly averages
    hourly_energy = df.groupby('Hour').agg({
        'Power_Consumption_W': 'mean',
        'Room_Temperature_C': 'mean'
    }).reset_index()
    
    # Create two separate charts instead of dual axis
    col1, col2 = st.columns(2)
    
    with col1:
        # Power consumption by hour
        fig3a = px.line(
            hourly_energy,
            x='Hour',
            y='Power_Consumption_W',
            title='Hourly Power Consumption',
            markers=True
        )
        fig3a.update_traces(line_color='#667eea', line_width=3)
        fig3a.update_layout(height=350)
        st.plotly_chart(fig3a, use_container_width=True)
    
    with col2:
        # Temperature by hour
        fig3b = px.line(
            hourly_energy,
            x='Hour',
            y='Room_Temperature_C',
            title='Hourly Temperature',
            markers=True
        )
        fig3b.update_traces(line_color='#ff7675', line_width=3)
        fig3b.update_layout(height=350)
        st.plotly_chart(fig3b, use_container_width=True)
    
    # Room-wise detailed table
    st.subheader("📋 Room-wise Detailed Statistics")
    st.dataframe(room_stats, use_container_width=True)

# 2. Device Status Analysis
with tab2:
    st.subheader("🖥️ Device Status & Performance Analysis")
    
    # Create metrics for each device
    devices = df['Device_ID'].unique()
    
    # Calculate device health metrics
    device_health = []
    for device in devices:
        device_data = df[df['Device_ID'] == device]
        
        # Calculate various metrics
        avg_temp = device_data['Room_Temperature_C'].mean()
        avg_power = device_data['Power_Consumption_W'].mean()
        error_rate = (device_data['Device_Error'] != 'None').mean() * 100
        avg_battery = device_data['Battery_Level_%'].mean()
        wifi_strength = device_data['WiFi_Signal_dBm'].mean()
        
        # Determine status
        if error_rate > 20 or avg_battery < 30:
            status = 'Critical'
            status_color = '#ff7675'
        elif error_rate > 10 or avg_battery < 50:
            status = 'Warning'
            status_color = '#fdcb6e'
        else:
            status = 'Optimal'
            status_color = '#00b894'
        
        device_health.append({
            'Device': device,
            'Avg Temp (°C)': round(avg_temp, 1),
            'Avg Power (W)': round(avg_power, 0),
            'Error Rate (%)': round(error_rate, 1),
            'Battery Level (%)': round(avg_battery, 0),
            'WiFi Signal (dBm)': round(wifi_strength, 0),
            'Status': status,
            'Status_Color': status_color
        })
    
    device_health_df = pd.DataFrame(device_health)
    
    # Display device health matrix
    col1, col2 = st.columns(2)
    
    with col1:
        # Device status distribution pie chart
        status_counts = device_health_df['Status'].value_counts()
        fig4 = px.pie(
            values=status_counts.values,
            names=status_counts.index,
            title='Device Status Distribution',
            color=status_counts.index,
            color_discrete_map={
                'Optimal': '#00b894',
                'Warning': '#fdcb6e',
                'Critical': '#ff7675'
            }
        )
        fig4.update_traces(textposition='inside', textinfo='percent+label')
        fig4.update_layout(height=400)
        st.plotly_chart(fig4, use_container_width=True)
    
    with col2:
        # Battery level across devices
        fig5 = px.bar(
            device_health_df.sort_values('Battery Level (%)'),
            x='Device',
            y='Battery Level (%)',
            title='Battery Levels by Device',
            color='Status',
            color_discrete_map={
                'Optimal': '#00b894',
                'Warning': '#fdcb6e',
                'Critical': '#ff7675'
            }
        )
        fig5.update_layout(height=400)
        st.plotly_chart(fig5, use_container_width=True)
    
    # Device health table
    st.subheader("📊 Device Health Summary")
    st.dataframe(device_health_df, use_container_width=True)

# 3. Recent Alerts Analysis
with tab3:
    st.subheader("🚨 IoT Device Alerts & Notifications")
    
    # Create alerts from the data
    alerts = []
    
    # Check for various alert conditions
    for idx, row in df.iterrows():
        alert_messages = []
        
        # Smoke level alerts
        if row['Smoke_Level'] == 'Critical':
            alert_messages.append(f"🚨 CRITICAL: Smoke detected in {row['Device_ID']}")
        elif row['Smoke_Level'] == 'Warning':
            alert_messages.append(f"⚠️ WARNING: Smoke warning in {row['Device_ID']}")
        
        # High temperature alerts
        if row['Room_Temperature_C'] > 28:
            alert_messages.append(f"🌡️ High temperature ({row['Room_Temperature_C']:.1f}°C) in {row['Device_ID']}")
        
        # High CO2 alerts
        if row['CO2_Level_ppm'] > 1500:
            alert_messages.append(f"💨 High CO2 level ({row['CO2_Level_ppm']}ppm) in {row['Device_ID']}")
        
        # Device error alerts
        if row['Device_Error'] != 'None':
            alert_messages.append(f"🔧 Device error ({row['Device_Error']}) in {row['Device_ID']}")
        
        # Low battery alerts
        if row['Battery_Level_%'] < 30:
            alert_messages.append(f"🔋 Low battery ({row['Battery_Level_%']}%) in {row['Device_ID']}")
        
        # Water leak alerts
        if row['Water_Leak_Sensor'] == 1:
            alert_messages.append(f"💧 Water leak detected in {row['Device_ID']}")
        
        # Add alerts to list
        for msg in alert_messages:
            if 'CRITICAL' in msg:
                severity = 'critical'
                alert_class = 'critical-alert'
            elif 'WARNING' in msg:
                severity = 'warning'
                alert_class = 'warning-alert'
            else:
                severity = 'info'
                alert_class = 'info-alert'
            
            alerts.append({
                'timestamp': row['Timestamp'],
                'device': row['Device_ID'],
                'message': msg,
                'severity': severity,
                'class': alert_class
            })
    
    # Convert to DataFrame and get recent alerts
    alerts_df = pd.DataFrame(alerts)
    
    if not alerts_df.empty:
        # Get last 20 alerts
        recent_alerts = alerts_df.sort_values('timestamp', ascending=False).head(20)
        
        # Alert statistics
        col1, col2, col3 = st.columns(3)
        
        with col1:
            critical_count = len(recent_alerts[recent_alerts['severity'] == 'critical'])
            st.metric("Critical Alerts", critical_count)
        
        with col2:
            warning_count = len(recent_alerts[recent_alerts['severity'] == 'warning'])
            st.metric("Warning Alerts", warning_count)
        
        with col3:
            info_count = len(recent_alerts[recent_alerts['severity'] == 'info'])
            st.metric("Info Alerts", info_count)
        
        # Display recent alerts
        st.subheader("📝 Recent Alert Log")
        
        for _, alert in recent_alerts.iterrows():
            time_str = alert['timestamp'].strftime("%H:%M:%S")
            
            st.markdown(f"""
            <div class="{alert['class']}">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="font-weight: bold;">{alert['device']}</div>
                    <div style="font-size: 0.8rem; color: #666;">{time_str}</div>
                </div>
                <div style="margin-top: 0.25rem;">{alert['message']}</div>
            </div>
            """, unsafe_allow_html=True)
        
        # Alert trend over time
        st.subheader("📈 Alert Trend Analysis")
        
        # Resample alerts by hour
        alerts_df['hour'] = alerts_df['timestamp'].dt.floor('H')
        alert_trend = alerts_df.groupby(['hour', 'severity']).size().reset_index(name='count')
        
        fig7 = px.line(
            alert_trend,
            x='hour',
            y='count',
            color='severity',
            title='Alert Frequency Over Time',
            color_discrete_map={
                'critical': '#dc3545',
                'warning': '#ffc107',
                'info': '#17a2b8'
            }
        )
        fig7.update_layout(height=400)
        st.plotly_chart(fig7, use_container_width=True)
        
    else:
        st.info("No alerts found in the dataset")

# 4. Suspicious Activity Detection
with tab4:
    st.subheader("🔍 Suspicious Activity Detection")
    
    # Define rules for suspicious activity
    suspicious_activities = []
    
    # Rule 1: Unusual power spikes
    for device in devices:
        device_data = df[df['Device_ID'] == device].copy()
        
        # Calculate moving average and standard deviation
        device_data['Power_MA'] = device_data['Power_Consumption_W'].rolling(window=5, min_periods=1).mean()
        device_data['Power_Std'] = device_data['Power_Consumption_W'].rolling(window=5, min_periods=1).std()
        
        # Find power spikes (more than 3 standard deviations from mean)
        # Fill NaN values for comparison
        device_data['Power_MA'] = device_data['Power_MA'].fillna(device_data['Power_Consumption_W'])
        device_data['Power_Std'] = device_data['Power_Std'].fillna(0)
        
        power_spikes = device_data[
            (device_data['Power_Consumption_W'] > device_data['Power_MA'] + 3 * device_data['Power_Std']) |
            (device_data['Power_Consumption_W'] < device_data['Power_MA'] - 3 * device_data['Power_Std'])
        ]
        
        for _, spike in power_spikes.iterrows():
            suspicious_activities.append({
                'timestamp': spike['Timestamp'],
                'device': device,
                'type': 'Power Spike',
                'details': f"Power: {spike['Power_Consumption_W']:.0f}W (Avg: {spike['Power_MA']:.0f}W)",
                'severity': 'high'
            })
    
    # Rule 2: Unusual temperature patterns
    for device in devices:
        device_data = df[df['Device_ID'] == device].copy()
        
        # Temperature changes more than 5°C in 1 minute
        device_data['Temp_Change'] = device_data['Room_Temperature_C'].diff().abs()
        temp_spikes = device_data[device_data['Temp_Change'] > 5]
        
        for _, spike in temp_spikes.iterrows():
            suspicious_activities.append({
                'timestamp': spike['Timestamp'],
                'device': device,
                'type': 'Rapid Temperature Change',
                'details': f"ΔTemp: {spike['Temp_Change']:.1f}°C in 1 min",
                'severity': 'medium'
            })
    
    # Rule 3: Door open with no motion
    door_no_motion = df[(df['Door_Status'] == 'Open') & (df['Motion_Detected'] == 0)]
    for _, event in door_no_motion.iterrows():
        suspicious_activities.append({
            'timestamp': event['Timestamp'],
            'device': event['Device_ID'],
            'type': 'Door Open - No Motion',
            'details': "Door opened but no motion detected",
            'severity': 'medium'
        })
    
    # Rule 4: High CO2 with closed doors
    high_co2 = df[(df['CO2_Level_ppm'] > 1800) & (df['Door_Status'] == 'Closed')]
    for _, event in high_co2.iterrows():
        suspicious_activities.append({
            'timestamp': event['Timestamp'],
            'device': event['Device_ID'],
            'type': 'High CO2 - Poor Ventilation',
            'details': f"CO2: {event['CO2_Level_ppm']}ppm, Door: Closed",
            'severity': 'high'
        })
    
    # Rule 5: Device errors during normal hours
    device_errors = df[(df['Device_Error'] != 'None') & (df['Hour'] >= 6) & (df['Hour'] <= 22)]
    for _, event in device_errors.iterrows():
        suspicious_activities.append({
            'timestamp': event['Timestamp'],
            'device': event['Device_ID'],
            'type': 'Device Error During Active Hours',
            'details': f"Error: {event['Device_Error']}",
            'severity': 'medium'
        })
    
    # Convert to DataFrame
    suspicious_df = pd.DataFrame(suspicious_activities)
    
    if not suspicious_df.empty:
        # Sort by timestamp and get recent activities
        suspicious_df = suspicious_df.sort_values('timestamp', ascending=False)
        
        # Display suspicious activity summary
        col1, col2, col3 = st.columns(3)
        
        with col1:
            high_risk = len(suspicious_df[suspicious_df['severity'] == 'high'])
            st.metric("High Risk Activities", high_risk, delta_color="inverse")
        
        with col2:
            medium_risk = len(suspicious_df[suspicious_df['severity'] == 'medium'])
            st.metric("Medium Risk Activities", medium_risk)
        
        with col3:
            unique_devices = suspicious_df['device'].nunique()
            st.metric("Devices Affected", unique_devices)
        
        # Display recent suspicious activities
        st.subheader("🚨 Detected Suspicious Activities")
        
        for idx, activity in suspicious_df.head(15).iterrows():
            time_str = activity['timestamp'].strftime("%H:%M:%S")
            severity_color = '#ff7675' if activity['severity'] == 'high' else '#fdcb6e'
            
            st.markdown(f"""
            <div class="suspicious-card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                    <div style="font-weight: bold; font-size: 1.1rem;">⚠️ {activity['type']}</div>
                    <div style="font-size: 0.8rem; opacity: 0.9;">{time_str}</div>
                </div>
                <div style="margin-bottom: 0.5rem;">
                    <span style="font-weight: bold;">Device:</span> {activity['device']}
                </div>
                <div style="margin-bottom: 0.5rem;">
                    <span style="font-weight: bold;">Details:</span> {activity['details']}
                </div>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-size: 0.8rem;">
                        Severity: <span style="color: {severity_color}; font-weight: bold;">{activity['severity'].upper()}</span>
                    </span>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        # Activity pattern analysis
        st.subheader("📈 Suspicious Activity Patterns")
        
        # Group by hour and type
        suspicious_df['hour'] = suspicious_df['timestamp'].dt.hour
        activity_pattern = suspicious_df.groupby(['hour', 'type']).size().reset_index(name='count')
        
        fig9 = px.bar(
            activity_pattern,
            x='hour',
            y='count',
            color='type',
            title='Suspicious Activity Distribution by Hour',
            barmode='stack'
        )
        fig9.update_layout(height=400)
        st.plotly_chart(fig9, use_container_width=True)
        
    else:
        st.success("✅ No suspicious activities detected in the dataset")
        st.markdown("""
        <div style="background: #d4edda; color: #155724; padding: 1rem; border-radius: 8px; border: 1px solid #c3e6cb;">
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.2rem;">✅</span>
                <span style="font-weight: bold;">All systems operating normally</span>
            </div>
            <div style="margin-top: 0.5rem; font-size: 0.9rem;">
                No unusual patterns or suspicious activities detected based on current analysis rules.
            </div>
        </div>
        """, unsafe_allow_html=True)

# Add Device Summary section
st.markdown("---")
st.subheader("📱 Device Summary")

# Calculate comprehensive device statistics
device_summary = []

for device in devices:
    device_data = df[df['Device_ID'] == device]
    
    # Basic stats
    record_count = len(device_data)
    time_range = f"{device_data['Timestamp'].min().strftime('%H:%M')} - {device_data['Timestamp'].max().strftime('%H:%M')}"
    
    # Environmental stats
    temp_stats = f"{device_data['Room_Temperature_C'].min():.1f}-{device_data['Room_Temperature_C'].max():.1f}°C"
    humidity_stats = f"{device_data['Humidity_%'].min():.0f}-{device_data['Humidity_%'].max():.0f}%"
    
    # Power stats
    power_stats = f"{device_data['Power_Consumption_W'].min():.0f}-{device_data['Power_Consumption_W'].max():.0f}W"
    total_energy = device_data['Power_Usage_kWh'].sum()
    
    # Air quality stats
    avg_aqi = device_data['Air_Quality_Index'].mean()
    avg_co2 = device_data['CO2_Level_ppm'].mean()
    
    # Device health
    error_count = (device_data['Device_Error'] != 'None').sum()
    avg_battery = device_data['Battery_Level_%'].mean()
    avg_wifi = device_data['WiFi_Signal_dBm'].mean()
    
    # Activity stats
    motion_count = device_data['Motion_Detected'].sum()
    door_open_count = (device_data['Door_Status'] == 'Open').sum()
    ac_on_count = (device_data['AC_Status'] == 'On').sum()
    
    device_summary.append({
        'Device': device,
        'Records': record_count,
        'Time Range': time_range,
        'Temperature Range': temp_stats,
        'Humidity Range': humidity_stats,
        'Power Range': power_stats,
        'Total Energy (kWh)': round(total_energy, 2),
        'Avg AQI': round(avg_aqi, 0),
        'Avg CO2': round(avg_co2, 0),
        'Errors': error_count,
        'Avg Battery %': round(avg_battery, 0),
        'Avg WiFi dBm': round(avg_wifi, 0),
        'Motion Events': motion_count,
        'Door Open Events': door_open_count,
        'AC On Events': ac_on_count
    })

device_summary_df = pd.DataFrame(device_summary)

# Display device cards in a grid
st.subheader("🖥️ Device Performance Overview")

# Create 3 columns for device cards
cols = st.columns(3)

for idx, device in enumerate(devices):
    with cols[idx % 3]:
        device_data = device_summary_df[device_summary_df['Device'] == device].iloc[0]
        
        # Determine device status based on metrics
        if device_data['Errors'] > 5 or device_data['Avg Battery %'] < 40:
            status = "⚠️ Needs Attention"
            status_color = "#fdcb6e"
        elif device_data['Errors'] > 0:
            status = "⚡ Minor Issues"
            status_color = "#fdcb6e"
        else:
            status = "✅ Optimal"
            status_color = "#00b894"
        
        st.markdown(f"""
        <div class="device-card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <div style="font-size: 1.2rem; font-weight: bold; color: #333;">{device}</div>
                <div style="color: {status_color}; font-weight: bold;">{status}</div>
            </div>
            
            <div style="margin-bottom: 0.5rem;">
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #666;">Energy:</span>
                    <span style="font-weight: bold;">{device_data['Total Energy (kWh)']} kWh</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #666;">Power:</span>
                    <span style="font-weight: bold;">{device_data['Power Range']}</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #666;">Temp:</span>
                    <span style="font-weight: bold;">{device_data['Temperature Range']}</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #666;">Battery:</span>
                    <span style="font-weight: bold;">{device_data['Avg Battery %']}%</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #666;">Errors:</span>
                    <span style="font-weight: bold; color: {'#ff7675' if device_data['Errors'] > 0 else '#00b894'}">
                        {device_data['Errors']}
                    </span>
                </div>
            </div>
            
            <div style="font-size: 0.8rem; color: #888; margin-top: 0.5rem;">
                {device_data['Time Range']}
            </div>
        </div>
        """, unsafe_allow_html=True)

# Sidebar with controls
with st.sidebar:
    st.header("⚙️ Dashboard Controls")
    
    # Date range selector
    st.subheader("📅 Date & Time Range")
    
    if not df.empty:
        min_date = df['Timestamp'].min().date()
        max_date = df['Timestamp'].max().date()
        
        date_range = st.date_input(
            "Select Date Range:",
            value=(min_date, max_date),
            min_value=min_date,
            max_value=max_date
        )
    
    # Device filter
    st.subheader("🔍 Device Filter")
    
    all_devices = st.checkbox("Select All Devices", value=True)
    
    if not all_devices:
        selected_devices = st.multiselect(
            "Select Devices to Analyze:",
            options=df['Device_ID'].unique().tolist(),
            default=df['Device_ID'].unique().tolist()[:3]
        )
    
    # Alert threshold settings
    st.subheader("🚨 Alert Settings")
    
    temp_threshold = st.slider(
        "Temperature Alert Threshold (°C):",
        min_value=20,
        max_value=35,
        value=28,
        step=1
    )
    
    co2_threshold = st.slider(
        "CO2 Alert Threshold (ppm):",
        min_value=800,
        max_value=2000,
        value=1500,
        step=100
    )
    
    battery_threshold = st.slider(
        "Low Battery Threshold (%):",
        min_value=10,
        max_value=50,
        value=30,
        step=5
    )
    
    # Refresh button
    st.markdown("---")
    if st.button("🔄 Refresh Analysis", use_container_width=True):
        st.rerun()
    
    # Export options
    st.markdown("---")
    st.subheader("📤 Export Data")
    
    if st.button("📊 Export Summary Report", use_container_width=True):
        st.success("Report export functionality would be implemented here")

# Footer
st.markdown("---")
footer_col1, footer_col2, footer_col3 = st.columns(3)

with footer_col1:
    st.markdown(f"**Total Records:** {len(df):,}")

with footer_col2:
    st.markdown(f"**Time Range:** {df['Timestamp'].min().strftime('%H:%M')} - {df['Timestamp'].max().strftime('%H:%M')}")

with footer_col3:
    st.markdown("**Dashboard Version:** 1.0")