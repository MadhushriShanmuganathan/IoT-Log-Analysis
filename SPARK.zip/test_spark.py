import os

# Force Spark to use Java 17
os.environ["JAVA_HOME"] = r"C:\Program Files\Eclipse Adoptium\jdk-17.0.17.10-hotspot"
os.environ["PATH"] = os.environ["JAVA_HOME"] + r"\bin;" + os.environ["PATH"]

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("TestSpark") \
    .master("local[*]") \
    .getOrCreate()

data = [(1, "Madhu"), (2, "ChatGPT")]
df = spark.createDataFrame(data, ["ID", "Name"])
df.show()

spark.stop()
