import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, when, avg, stddev, min as spark_min, max as spark_max
)
import pandas as pd
import matplotlib.pyplot as plt

# ===============================
# 1️⃣ Start Spark
# ===============================
spark = SparkSession.builder \
    .appName("IoT Log Analysis - Advanced") \
    .master("local[*]") \
    .getOrCreate()

print("✔ Spark Started Successfully")

# ===============================
# 2️⃣ Load Dataset
# ===============================
file_path = "iot_logs.csv"   # Make sure CSV exists in this folder

df = spark.read.csv(file_path, header=True, inferSchema=True)

print("\n=== Dataset Preview ===")
df.show(10)
df.printSchema()

# ===============================
# 3️⃣ Data Cleaning
# ===============================
print("\n=== 3. DATA CLEANING ===")

# 3.1 Replace INVALID readings with NULL (so we can drop or analyze)
df_clean = df

# Invalid battery level (<0 or >100)
df_clean = df_clean.withColumn(
    "Battery_Level(%)",
    when((col("Battery_Level(%)") < 0) | (col("Battery_Level(%)") > 100), None)
    .otherwise(col("Battery_Level(%)"))
)

# Invalid motor temperature (too extreme, e.g. below -40 or above 150 °C)
df_clean = df_clean.withColumn(
    "Motor_Temp(°C)",
    when((col("Motor_Temp(°C)") < -40) | (col("Motor_Temp(°C)") > 150), None)
    .otherwise(col("Motor_Temp(°C)"))
)

# Invalid speed (negative or unrealistically > 200 km/h)
df_clean = df_clean.withColumn(
    "Speed(km/h)",
    when((col("Speed(km/h)") < 0) | (col("Speed(km/h)") > 200), None)
    .otherwise(col("Speed(km/h)"))
)

# Invalid tire pressure (too low/high, e.g. < 15 or > 60 psi)
df_clean = df_clean.withColumn(
    "Tire_Pressure(psi)",
    when((col("Tire_Pressure(psi)") < 15) | (col("Tire_Pressure(psi)") > 60), None)
    .otherwise(col("Tire_Pressure(psi)"))
)

# Invalid sensor value (negative when it shouldn't be)
df_clean = df_clean.withColumn(
    "Value",
    when(col("Value") < 0, None).otherwise(col("Value"))
)

print("\n→ After replacing invalid readings (showing 5 rows):")
df_clean.show(5)

# 3.2 Remove rows with missing critical values
critical_cols = [
    "Timestamp",
    "Device_id",
    "Motor_Temp(°C)",
    "Battery_Level(%)",
    "Speed(km/h)",
    "Tire_Pressure(psi)"
]

df_clean = df_clean.na.drop(subset=critical_cols)

print("\n→ After dropping rows with NULL in critical columns:")
df_clean.show(5)

# 3.3 Filter out faulty sensors (for normal analysis)
# Use only non-error rows for performance stats
df_analysis = df_clean.filter(col("Status") != "error")

print("\n→ Cleaned dataset for analysis (no 'error' status rows):")
df_analysis.show(5)

# ===============================
# 4️⃣ Device Performance Summary
# ===============================
print("\n=== 4. DEVICE PERFORMANCE SUMMARY ===")

print("\n→ Device Usage Summary (number of records per device):")
usage_summary = df_analysis.groupBy("Device_id").count()
usage_summary.show()

print("\n→ Device Metrics Summary (temperature, battery, speed, pressure):")
device_metrics = df_analysis.groupBy("Device_id").agg(
    avg("Motor_Temp(°C)").alias("avg_temperature"),
    stddev("Motor_Temp(°C)").alias("temp_stddev"),
    avg("Battery_Level(%)").alias("avg_battery"),
    avg("Speed(km/h)").alias("avg_speed"),
    avg("Tire_Pressure(psi)").alias("avg_tire_pressure"),
    spark_min("Motor_Temp(°C)").alias("min_temp"),
    spark_max("Motor_Temp(°C)").alias("max_temp")
)
device_metrics.show()

# ===============================
# 5️⃣ Per-Device Trend Analysis
# ===============================
print("\n=== 5. PER-DEVICE TRENDS (Temperature, Battery, Speed, Pressure) ===")

print("\n→ Example: Aggregated trends per device:")
trends_per_device = df_analysis.groupBy("Device_id").agg(
    avg("Motor_Temp(°C)").alias("avg_temp"),
    avg("Battery_Level(%)").alias("avg_battery"),
    avg("Speed(km/h)").alias("avg_speed"),
    avg("Tire_Pressure(psi)").alias("avg_tire_pressure")
)
trends_per_device.show()

# ===============================
# 6️⃣ Anomaly Detection
# ===============================
print("\n=== 6. ANOMALY DETECTION ===")

# 6.1 High Motor Temperature (Fault Prediction)
HIGH_TEMP_THRESHOLD = 85.0
high_temp_faults = df_clean.filter(col("Motor_Temp(°C)") > HIGH_TEMP_THRESHOLD)

print(f"\n→ High Motor Temperature events (>{HIGH_TEMP_THRESHOLD} °C):")
high_temp_faults.show(20, truncate=False)

# 6.2 Low Battery / Battery dropping too fast (simplified)
LOW_BATTERY_THRESHOLD = 20
low_battery_faults = df_clean.filter(col("Battery_Level(%)") < LOW_BATTERY_THRESHOLD)

print(f"\n→ Low Battery events (<{LOW_BATTERY_THRESHOLD}%):")
low_battery_faults.show(20, truncate=False)

# ===============================
# 7️⃣ Visualizations (Matplotlib + Pandas)
# ===============================
print("\n=== 7. VISUALIZATIONS (Matplotlib) ===")
print("→ Creating plots for one sample device (ev-sensor-1)...")

# Choose a device to visualize
sample_device_id = "ev-sensor-1"

device_df = df_analysis.filter(col("Device_id") == sample_device_id) \
    .orderBy("Timestamp") \
    .select("Timestamp", "Motor_Temp(°C)", "Battery_Level(%)")

# Convert to Pandas for plotting
pdf = device_df.toPandas()

if not pdf.empty:
    # Temperature over time
    plt.figure()
    plt.plot(pdf["Timestamp"], pdf["Motor_Temp(°C)"])
    plt.xlabel("Time")
    plt.ylabel("Motor Temperature (°C)")
    plt.title(f"Temperature over time - {sample_device_id}")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    # Battery level over time
    plt.figure()
    plt.plot(pdf["Timestamp"], pdf["Battery_Level(%)"])
    plt.xlabel("Time")
    plt.ylabel("Battery Level (%)")
    plt.title(f"Battery percentage trend - {sample_device_id}")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
else:
    print(f"No data available for device {sample_device_id} for visualization.")

# ===============================
# 8️⃣ Save Output as Reports
# ===============================
print("\n=== 8. SAVING OUTPUT REPORTS ===")

output_dir = "output"
# Spark will create folder if not exists

# Cleaned dataset
df_clean.write.mode("overwrite").csv(f"{output_dir}/cleaned_data", header=True)

# Usage summary
usage_summary.write.mode("overwrite").csv(f"{output_dir}/device_usage_summary", header=True)

# Device metrics
device_metrics.write.mode("overwrite").csv(f"{output_dir}/device_metrics_summary", header=True)

# High temp faults
high_temp_faults.write.mode("overwrite").csv(f"{output_dir}/high_temp_faults", header=True)

# Low battery faults
low_battery_faults.write.mode("overwrite").csv(f"{output_dir}/low_battery_faults", header=True)

print(f"\n✔ Reports saved under ./{output_dir}/ (each as a folder with CSV part files)")

# Keep Spark alive so Web UI stays up until you finish viewing
input("\nAnalysis done. Press Enter to stop Spark and close... ")

spark.stop()
print("✔ Spark Stopped. Bye!")
