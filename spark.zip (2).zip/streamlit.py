import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import *

# Page configuration
st.set_page_config(
    page_title="IoT Device Analytics",
    page_icon="📊",
    layout="wide"
)

# Custom CSS - Simplified with better alert visibility
st.markdown("""
<style>
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin-bottom: 1rem;
    }
    
    .alert-critical { 
        background-color: #ffebee !important; 
        border-left: 4px solid #f44336 !important; 
        padding: 1rem !important; 
        border-radius: 6px !important; 
        margin-bottom: 0.75rem !important;
        color: #333 !important;
        border: 1px solid #f44336 !important;
    }
    
    .alert-warning { 
        background-color: #fff8e1 !important; 
        border-left: 4px solid #ff9800 !important; 
        padding: 1rem !important; 
        border-radius: 6px !important; 
        margin-bottom: 0.75rem !important;
        color: #333 !important;
        border: 1px solid #ff9800 !important;
    }
    
    .alert-info { 
        background-color: #e3f2fd !important; 
        border-left: 4px solid #2196f3 !important; 
        padding: 1rem !important; 
        border-radius: 6px !important; 
        margin-bottom: 0.75rem !important;
        color: #333 !important;
        border: 1px solid #2196f3 !important;
    }
    
    .status-online { color: #28a745; font-weight: bold; }
    .status-offline { color: #dc3545; font-weight: bold; }
    .status-warning { color: #ff9800; font-weight: bold; }
</style>
""", unsafe_allow_html=True)

# Initialize Spark Session for Web UI
@st.cache_resource
def init_spark_session():
    spark = SparkSession.builder \
        .appName("IoT Device Analytics Dashboard") \
        .master("local[*]") \
        .config("spark.driver.memory", "2g") \
        .config("spark.executor.memory", "2g") \
        .config("spark.ui.port", "4043") \
        .config("spark.sql.debug.maxToStringFields", "100") \
        .getOrCreate()
    
    return spark

# Initialize Spark
spark = init_spark_session()

# Show Spark info in sidebar - MOVED OUTSIDE CACHED FUNCTION
with st.sidebar:
    st.markdown("---")
    st.subheader("🔗 Spark Connection")
    st.write(f"**App Name:** IoT Dashboard")
    st.write(f"**Spark UI:** [http://localhost:4043](http://localhost:4043)")
    
    if st.button("Open Spark UI", use_container_width=True, key="spark_ui_button"):
        st.info("Open http://localhost:4043 in your browser")
        # You can also use webbrowser to auto-open
        import webbrowser
        webbrowser.open("http://localhost:4043")

# Load the dataset
@st.cache_data
def load_data():
    try:
        # Load with Spark first
        spark_df = spark.read \
            .option("header", "true") \
            .option("inferSchema", "true") \
            .csv("iot_logs.csv")
        
        # Convert to Pandas for compatibility with existing code
        df = spark_df.toPandas()
        df['Timestamp'] = pd.to_datetime(df['Timestamp'])
        df['Hour'] = df['Timestamp'].dt.hour
        return df
    except FileNotFoundError:
        # Create sample data for demonstration
        np.random.seed(42)
        devices = ['Living_Room', 'Bedroom', 'Kitchen', 'Office', 'Garage']
        timestamps = pd.date_range(start='2024-01-01', periods=500, freq='5min')
        
        data = []
        for ts in timestamps:
            for device in devices:
                data.append({
                    'Timestamp': ts,
                    'Device_ID': device,
                    'Power_Consumption_W': np.random.uniform(50, 300),
                    'Power_Usage_kWh': np.random.uniform(0.1, 0.5),
                    'Room_Temperature_C': np.random.uniform(18, 28),
                    'Humidity_%': np.random.uniform(30, 70),
                    'Device_Error': np.random.choice(['None', 'Connection Lost', 'Sensor Fault'], p=[0.9, 0.05, 0.05]),
                    'Battery_Level_%': np.random.uniform(40, 100),
                    'WiFi_Signal_dBm': np.random.uniform(-70, -30),
                })
        
        df = pd.DataFrame(data)
        
        # Convert to Spark DataFrame to cache it
        spark_df = spark.createDataFrame(df)
        spark_df.cache()
        
        return df

# Load data
df = load_data()

# Simple Controls Sidebar (moved up so filters affect all views)
with st.sidebar:
    st.header("⚙️ Controls")
    
    # Auto-refresh toggle
    auto_refresh = st.toggle("Auto-refresh", value=False, 
                           help="Automatically refresh data every 30 seconds")
    
    # Device filter
    st.subheader("Device Filter")
    all_devices = df['Device_ID'].unique().tolist()
    selected_devices = st.multiselect(
        "Select devices to show:",
        options=all_devices,
        default=all_devices,
        help="Filter data by specific devices"
    )
    
    st.markdown("---")
    
    # Export all data
    st.subheader("Export Data")
    
    if st.button("Export All Data", use_container_width=True, type="primary", key="export_button"):
        csv = df.to_csv(index=False)
        st.download_button(
            label="📥 Download Full Dataset",
            data=csv,
            file_name=f"iot_full_data_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv",
            use_container_width=True,
            key="download_button"
        )

# Apply filter globally
filtered_df = df[df['Device_ID'].isin(selected_devices)].copy()

# Dashboard Header
st.title("📊 IoT Device Analytics Dashboard")
st.info(f"✅ Spark Session Active | Web UI: http://localhost:4043")

# Top Metrics - Simplified to 3
col1, col2, col3 = st.columns(3)

with col1:
    total_energy = filtered_df['Power_Usage_kWh'].sum()
    st.metric("Total Energy", f"{total_energy:.1f} kWh", 
              help="Sum of all power usage across all devices")

with col2:
    total_devices = filtered_df['Device_ID'].nunique()
    st.metric("Active Devices", total_devices,
              help="Number of unique IoT devices")

with col3:
    error_count = (filtered_df['Device_Error'] != 'None').sum()
    st.metric("Device Errors", error_count,
              help="Total device errors detected")

# Navigation tabs for requested experiences
rooms_tab, automations_tab, analytics_tab, energy_tab, alerts_tab = st.tabs([
    "🏠 Rooms",
    "🤖 Automations",
    "📊 Analytics",
    "⚡ Energy",
    "🚨 Alerts & Status"
])

# 1. Rooms Tab – 3D visualization of rooms and IoT devices
with rooms_tab:
    st.header("3D Room & Device Visualization")
    
    # Simple room coordinates for a floor layout
    room_positions = {
        'Living_Room': (0, 0, 0),
        'Bedroom': (4, 0, 0),
        'Kitchen': (0, 4, 0),
        'Office': (4, 4, 0),
        'Garage': (8, 0, 0)
    }
    
    rooms_df = pd.DataFrame([
        {'Room': room, 'x': pos[0], 'y': pos[1], 'z': pos[2]}
        for room, pos in room_positions.items()
    ])
    
    # Map devices to room coordinates (fallback to origin if missing)
    device_coords = filtered_df[['Device_ID']].drop_duplicates().copy()
    device_coords[['x', 'y', 'z']] = device_coords['Device_ID'].apply(
        lambda r: room_positions.get(r, (0, 0, 0))
    ).apply(pd.Series)
    
    room_fig = go.Figure()
    room_fig.add_trace(go.Scatter3d(
        x=rooms_df['x'], y=rooms_df['y'], z=rooms_df['z'],
        mode='markers+text',
        marker=dict(size=10, color='lightblue'),
        text=rooms_df['Room'],
        textposition="bottom center",
        name="Rooms"
    ))
    
    room_fig.add_trace(go.Scatter3d(
        x=device_coords['x'], y=device_coords['y'], z=device_coords['z'],
        mode='markers+text',
        marker=dict(size=6, color='orange'),
        text=device_coords['Device_ID'],
        textposition="top center",
        name="IoT Devices"
    ))
    
    room_fig.update_layout(
        height=500,
        margin=dict(l=0, r=0, b=0, t=20),
        scene=dict(
            xaxis_title="X (m)",
            yaxis_title="Y (m)",
            zaxis_title="Z (m)"
        )
    )
    
    st.plotly_chart(room_fig, use_container_width=True)

# 2. Automations Tab – Device counts for home automations
with automations_tab:
    st.header("Automation Overview")
    st.metric("IoT Devices in Home", filtered_df['Device_ID'].nunique())
    
    device_counts = filtered_df['Device_ID'].value_counts().reset_index()
    device_counts.columns = ['Device', 'Records']
    st.dataframe(device_counts, use_container_width=True, hide_index=True)

# 3. Analytics Tab – Device health and performance
with analytics_tab:
    st.header("Device Performance Overview")
    
    # Room statistics - Only essential columns
    room_stats = filtered_df.groupby('Device_ID').agg({
        'Power_Usage_kWh': 'sum',
        'Power_Consumption_W': 'mean',
        'Room_Temperature_C': 'mean',
        'Battery_Level_%': 'mean',
        'Device_Error': lambda x: (x != 'None').sum()
    }).round(2)
    
    room_stats.columns = ['Total_kWh', 'Avg_Power_W', 'Avg_Temp_C', 'Avg_Battery_%', 'Error_Count']
    room_stats = room_stats.reset_index()
    
    # Essential visualization: Bar chart for energy consumption
    st.subheader("Energy Consumption by Device")
    fig1 = px.bar(
        room_stats.sort_values('Total_kWh', ascending=False),
        x='Device_ID',
        y='Total_kWh',
        title='',
        color='Total_kWh',
        color_continuous_scale='blues',
        labels={'Device_ID': 'Device', 'Total_kWh': 'Energy (kWh)'}
    )
    fig1.update_layout(height=400, showlegend=False)
    st.plotly_chart(fig1, use_container_width=True)
    
    # Device status table - Clean and essential
    st.subheader("Device Status Summary")
    
    # Add simple status calculation
    device_status_list = []
    for _, row in room_stats.iterrows():
        if row['Error_Count'] > 5:
            status = "Critical"
            status_color = "status-offline"
        elif row['Error_Count'] > 0 or row['Avg_Battery_%'] < 30:
            status = "Warning"
            status_color = "status-warning"
        else:
            status = "Normal"
            status_color = "status-online"
        
        device_status_list.append({
            'Device': row['Device_ID'],
            'Status': status,
            'Energy (kWh)': row['Total_kWh'],
            'Avg Power (W)': row['Avg_Power_W'],
            'Avg Temp (°C)': row['Avg_Temp_C'],
            'Battery (%)': row['Avg_Battery_%'],
            'Errors': row['Error_Count']
        })
    
    device_status_df = pd.DataFrame(device_status_list)
    
    # Display as clean table
    st.dataframe(
        device_status_df,
        use_container_width=True,
        hide_index=True,
        column_config={
            'Device': st.column_config.TextColumn("Device", width="medium"),
            'Status': st.column_config.TextColumn("Status", width="small"),
            'Energy (kWh)': st.column_config.NumberColumn("Energy (kWh)", format="%.1f"),
            'Avg Power (W)': st.column_config.NumberColumn("Power (W)", format="%.0f"),
            'Avg Temp (°C)': st.column_config.NumberColumn("Temp (°C)", format="%.1f"),
            'Battery (%)': st.column_config.NumberColumn("Battery %", format="%.0f"),
            'Errors': st.column_config.NumberColumn("Errors", format="%d")
        }
    )
    
    # Simple scatter plot for battery vs temperature
    st.subheader("Battery Level vs Temperature")
    fig2 = px.scatter(
        room_stats,
        x='Avg_Temp_C',
        y='Avg_Battery_%',
        size='Avg_Power_W',
        color='Device_ID',
        hover_data=['Device_ID', 'Error_Count'],
        title='',
        labels={
            'Avg_Temp_C': 'Average Temperature (°C)',
            'Avg_Battery_%': 'Average Battery (%)',
            'Avg_Power_W': 'Average Power (W)'
        }
    )
    fig2.update_layout(height=400)
    st.plotly_chart(fig2, use_container_width=True)

# 4. Energy Tab – Electricity consumption summary
with energy_tab:
    st.header("Energy Consumption")
    energy_by_device = filtered_df.groupby('Device_ID')['Power_Usage_kWh'].sum().reset_index()
    energy_fig = px.pie(
        energy_by_device,
        names='Device_ID',
        values='Power_Usage_kWh',
        title='Energy Usage Share by Device'
    )
    energy_fig.update_traces(textposition='inside', textinfo='percent+label')
    st.plotly_chart(energy_fig, use_container_width=True)

# 5. Alerts & Status Tab
with alerts_tab:
    st.header("Device Alerts & Status Monitoring")
    
    # Generate essential alerts only
    alerts = []
    
    # Essential alert types only
    for _, row in df.iterrows():
        # Temperature alerts
        if row['Room_Temperature_C'] > 28:
            alerts.append({
                'timestamp': row['Timestamp'],
                'device': row['Device_ID'],
                'type': 'High Temperature',
                'message': f"Temperature: {row['Room_Temperature_C']:.1f}°C",
                'severity': 'warning'
            })
        elif row['Room_Temperature_C'] < 16:
            alerts.append({
                'timestamp': row['Timestamp'],
                'device': row['Device_ID'],
                'type': 'Low Temperature',
                'message': f"Temperature: {row['Room_Temperature_C']:.1f}°C",
                'severity': 'warning'
            })
        
        # Battery alerts - essential only
        if row['Battery_Level_%'] < 20:
            alerts.append({
                'timestamp': row['Timestamp'],
                'device': row['Device_ID'],
                'type': 'Low Battery',
                'message': f"Battery: {row['Battery_Level_%']:.0f}%",
                'severity': 'critical'
            })
        elif row['Battery_Level_%'] < 30:
            alerts.append({
                'timestamp': row['Timestamp'],
                'device': row['Device_ID'],
                'type': 'Low Battery',
                'message': f"Battery: {row['Battery_Level_%']:.0f}%",
                'severity': 'warning'
            })
        
        # Device error alerts
        if row['Device_Error'] != 'None':
            alerts.append({
                'timestamp': row['Timestamp'],
                'device': row['Device_ID'],
                'type': 'Device Error',
                'message': f"Error: {row['Device_Error']}",
                'severity': 'critical'
            })
    
    alerts_df = pd.DataFrame(alerts)
    
    if not alerts_df.empty:
        # Get recent alerts (last 30)
        recent_alerts = alerts_df.sort_values('timestamp', ascending=False).head(30)
        
        # Alert summary in columns
        st.subheader("Alert Summary")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            critical_count = len(recent_alerts[recent_alerts['severity'] == 'critical'])
            st.metric("Critical Alerts", critical_count, 
                     delta=f"{critical_count} urgent", delta_color="inverse")
        
        with col2:
            warning_count = len(recent_alerts[recent_alerts['severity'] == 'warning'])
            st.metric("Warning Alerts", warning_count,
                     delta=f"{warning_count} warnings")
        
        with col3:
            total_alerts = len(recent_alerts)
            st.metric("Total Alerts", total_alerts,
                     delta=f"Last 30 records")
        
        # Filter controls - Simple
        st.subheader("Recent Alerts")
        
        # Severity filter
        severity_options = st.multiselect(
            "Filter by alert type:",
            ['critical', 'warning'],
            default=['critical', 'warning'],
            key="severity_filter"
        )
        
        # Display alerts with better visibility
        filtered_alerts = recent_alerts[recent_alerts['severity'].isin(severity_options)]
        
        if not filtered_alerts.empty:
            for _, alert in filtered_alerts.iterrows():
                time_str = alert['timestamp'].strftime("%H:%M")
                
                if alert['severity'] == 'critical':
                    alert_class = "alert-critical"
                    severity_icon = "🔴"
                    severity_text = "CRITICAL"
                else:  # warning
                    alert_class = "alert-warning"
                    severity_icon = "🟡"
                    severity_text = "WARNING"
                
                # Improved alert display with better contrast
                st.markdown(f"""
                <div class="{alert_class}">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.5rem;">
                        <div style="font-size: 1.1rem;">
                            <strong>{severity_icon} {severity_text}</strong>
                        </div>
                        <div style="font-size: 0.9rem; font-weight: bold; color: #555;">{time_str}</div>
                    </div>
                    <div style="font-size: 1rem; margin-bottom: 0.25rem;">
                        <strong>Device:</strong> {alert['device']}
                    </div>
                    <div style="font-size: 1rem; margin-bottom: 0.25rem;">
                        <strong>Type:</strong> {alert['type']}
                    </div>
                    <div style="font-size: 1rem;">
                        <strong>Details:</strong> {alert['message']}
                    </div>
                </div>
                """, unsafe_allow_html=True)
            
            # Simple alert trend visualization
            st.subheader("Alert Trends")
            
            # Group by hour for visualization
            filtered_alerts['hour'] = filtered_alerts['timestamp'].dt.hour
            hourly_counts = filtered_alerts.groupby(['hour', 'severity']).size().reset_index(name='count')
            
            if not hourly_counts.empty:
                fig3 = px.bar(
                    hourly_counts,
                    x='hour',
                    y='count',
                    color='severity',
                    title='Alerts by Hour of Day',
                    barmode='group',
                    color_discrete_map={
                        'critical': '#f44336',
                        'warning': '#ff9800'
                    },
                    labels={
                        'hour': 'Hour of Day',
                        'count': 'Number of Alerts',
                        'severity': 'Alert Type'
                    }
                )
                fig3.update_layout(height=350)
                st.plotly_chart(fig3, use_container_width=True)
            
            # Export option
            st.download_button(
                label="📥 Download Alerts CSV",
                data=filtered_alerts.to_csv(index=False).encode('utf-8'),
                file_name=f"alerts_{datetime.now().strftime('%Y%m%d')}.csv",
                mime="text/csv",
                use_container_width=True,
                key="alerts_download"
            )
        else:
            st.info("No alerts match the selected filters.")
    else:
        st.success("✅ No alerts detected in the current data")
        
        # Show empty state visualization
        st.markdown("""
        <div style="text-align: center; padding: 3rem; background: #e8f5e9; border-radius: 10px; margin: 2rem 0;">
            <div style="font-size: 4rem; margin-bottom: 1rem;">✅</div>
            <div style="font-size: 1.5rem; font-weight: bold; color: #2e7d32; margin-bottom: 0.5rem;">
                All Systems Normal
            </div>
            <div style="color: #388e3c;">
                No alerts detected. All devices are operating within normal parameters.
            </div>
        </div>
        """, unsafe_allow_html=True)

# Data Quality Check (Minimal)
with st.expander("📋 Data Quality Check", expanded=False):
    st.subheader("Data Overview")
    
    col1, col2 = st.columns(2)
    
    with col1:
        total_records = len(df)
        st.metric("Total Records", f"{total_records:,}")
    
    with col2:
        time_range_hours = (df['Timestamp'].max() - df['Timestamp'].min()).total_seconds() / 3600
        st.metric("Time Coverage", f"{time_range_hours:.1f} hours")
    
    # Simple missing data check
    st.subheader("Missing Data Summary")
    missing_data = df.isnull().sum()
    missing_df = pd.DataFrame({
        'Column': missing_data.index,
        'Missing Values': missing_data.values,
        'Percentage': (missing_data.values / len(df) * 100).round(1)
    })
    missing_df = missing_df[missing_df['Missing Values'] > 0]
    
    if not missing_df.empty:
        st.dataframe(missing_df, use_container_width=True, hide_index=True)
    else:
        st.success("✅ No missing data detected")

# Footer - Minimal
st.markdown("---")
st.caption(f"Dashboard last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} • Data range: {df['Timestamp'].min().strftime('%b %d')} to {df['Timestamp'].max().strftime('%b %d')} • Spark UI: http://localhost:4043")